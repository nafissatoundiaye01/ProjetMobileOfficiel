package com.juraj.fancyloginscreen.ui.theme

import androidx.compose.ui.graphics.Color

val LightBlue800 = Color(0xFF0277bd)
val LightBlue500 = Color(0xFF58a5f0)
val LightBlue900 = Color(0xFF004c8c)