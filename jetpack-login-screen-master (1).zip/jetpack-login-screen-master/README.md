# Simple Login UI with Background Video in Jetpack Compose 

## [Watch it on YouTube](https://youtu.be/-oT9-IbPQWY)

Fancy mobile login screen using Jetpack Compose. I use ExoPlayer to render the video as a nice background animation. 

### Preview

![App UI](screenshots/screenshot.png)

